#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME}

#end

#parse("File Header.java")
class ${NAME} : SimpleAbstractAdapter<${VIEWHOLDER_CLASS}>() {

    override fun getLayout(viewType: Int): Int {
        return R.layout.${LAYOUT_RES_ID}
    }
    
    override fun bindView(item: ${VIEWHOLDER_CLASS}, viewHolder: VH) {
        viewHolder.itemView.apply {
            //UI setting code
        }
    }
    
 }