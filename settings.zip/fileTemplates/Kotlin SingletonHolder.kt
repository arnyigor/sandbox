#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME}

#end
#parse("File Header.java")
class ${NAME} private constructor(val context: Context) {
    companion object : SingletonHolder<${NAME}, Context>(::${NAME}) 
}