#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME}

#end
#parse("File Header.java")
object ${NAME} {
    interface View : BaseMvpView {

    }

    interface Presenter : BaseMvpPresenter<View> {

    }
}