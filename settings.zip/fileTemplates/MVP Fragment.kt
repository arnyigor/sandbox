#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME}

#end
#parse("File Header.java")

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup

class ${NAME} : BaseMvpFragment<${ContractName}.View, ${PresenterName}>(), ${ContractName}.View {

    override fun initPresenter(): ${PresenterName} {
        return ${PresenterName}()
    }

    companion object {
        fun newInstance(): ${NAME} {
            val fragment = ${NAME}()
            return fragment
        }
    }
    
    override fun onCreateView(inflater: LayoutInflater, parent: ViewGroup?, state: Bundle?): View? {
        return inflater.inflate(R.layout.${layout},parent,false)
    }
}
